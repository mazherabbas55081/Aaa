
import streamlit as st
from pathlib import Path
import pandas as pd
import random

# ============================================================
# PNPI - Pak Navy Polytechnic Institute
# Mechatronic Engineering | 5-Semester Student Portal
# Python + Streamlit only
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
ASSET_DIR = BASE_DIR / "assets"

st.set_page_config(
    page_title="PNPI | Mechatronic Engineering",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------- Styling -------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
    --navy:#071a33;
    --navy2:#0b2b4f;
    --cyan:#2dd4bf;
    --gold:#f4b942;
    --white:#f8fbff;
    --muted:#a8bdd1;
}

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background:
      radial-gradient(circle at 10% 0%, rgba(45,212,191,.10), transparent 28%),
      radial-gradient(circle at 90% 10%, rgba(244,185,66,.08), transparent 24%),
      linear-gradient(180deg, #061426 0%, #081d34 42%, #f4f7fb 42%, #f4f7fb 100%);
}

.block-container { padding-top: 1.2rem; max-width: 1400px; }

.hero {
    background: linear-gradient(135deg, rgba(7,26,51,.98), rgba(11,43,79,.96));
    border: 1px solid rgba(45,212,191,.28);
    border-radius: 26px;
    padding: 28px 30px;
    color: white;
    box-shadow: 0 18px 45px rgba(0,0,0,.18);
    margin-bottom: 22px;
}
.hero h1 { margin: 0; font-size: 2.2rem; font-weight: 800; }
.hero p { color: #c8d8e8; margin: 6px 0 0; font-size: 1rem; }
.pill {
    display:inline-block; padding:7px 12px; border-radius:999px;
    background:rgba(45,212,191,.13); color:#7ef3df;
    border:1px solid rgba(45,212,191,.3); margin-top:14px; font-size:.85rem;
}
.card {
    background:white; border:1px solid #e3eaf2; border-radius:18px;
    padding:20px; box-shadow:0 8px 28px rgba(13,38,64,.07); margin-bottom:16px;
}
.card h3 { color:#0b2b4f; margin-top:0; }
.small { color:#61758a; font-size:.9rem; }
.metric {
    background:white; border-radius:16px; padding:18px; border:1px solid #e4eaf1;
}
.metric .v { font-size:1.65rem; font-weight:800; color:#0b2b4f; }
.metric .l { color:#6b7d90; font-size:.85rem; }
.section-title { color:#0b2b4f; font-size:1.55rem; font-weight:800; margin:28px 0 12px; }
.badge-pass { color:#087f5b; background:#d3f9d8; padding:5px 10px; border-radius:999px; font-weight:700; }
.badge-reexam { color:#9a6700; background:#fff3bf; padding:5px 10px; border-radius:999px; font-weight:700; }
.badge-fail { color:#c92a2a; background:#ffe3e3; padding:5px 10px; border-radius:999px; font-weight:700; }
.stButton > button {
    border-radius:12px; border:0; font-weight:700; padding:10px 18px;
}
footer { visibility:hidden; }
</style>
""", unsafe_allow_html=True)

# ------------------------- Data -------------------------
SEMESTERS = {
    1: {
        "title": "Semester 1 — Foundation",
        "monogram": "semester_s1.png",
        "subjects": [
            "Engineering Mathematics I", "Applied Physics", "Engineering Drawing",
            "Electrical Fundamentals", "Mechanical Fundamentals", "Computer Fundamentals",
            "Technical English", "Workshop Practice"
        ],
        "teachers": ["Dr. Hamza Qureshi","Engr. Sara Malik","Engr. Bilal Ahmed","Engr. Ayesha Khan",
                     "Engr. Usman Tariq","Engr. Farhan Ali","Ms. Hina Raza","Engr. Saad Mahmood"],
    },
    2: {
        "title": "Semester 2 — Circuits & Machines",
        "monogram": "semester_s2.png",
        "subjects": [
            "Engineering Mathematics II", "Digital Electronics", "Electrical Machines",
            "Engineering Mechanics", "Programming for Engineers", "Manufacturing Processes",
            "Technical Communication"
        ],
        "teachers": ["Dr. Hamza Qureshi","Engr. Maryam Shah","Engr. Talha Iqbal","Engr. Naveed Khan",
                     "Engr. Zain Ahmed","Engr. Rida Noor","Ms. Hina Raza"],
    },
    3: {
        "title": "Semester 3 — Control Systems",
        "monogram": "semester_s3.png",
        "subjects": [
            "Control Systems I", "Sensors & Instrumentation", "Microcontrollers",
            "Pneumatics & Hydraulics", "CAD for Mechatronics", "Industrial Electronics",
            "Engineering Statistics"
        ],
        "teachers": ["Engr. Waleed Hassan","Engr. Iqra Saeed","Engr. Danish Ali","Engr. Mahnoor Ahmed",
                     "Engr. Rehan Siddiqui","Engr. Komal Fatima","Dr. Hassan Raza"],
    },
    4: {
        "title": "Semester 4 — Robotics",
        "monogram": "semester_s4.png",
        "subjects": [
            "Robotics Engineering", "PLC & Industrial Automation", "Embedded Systems",
            "Machine Vision", "Mechatronics Laboratory"
        ],
        "teachers": ["Engr. Salman Farooq","Engr. Areeba Khan","Engr. Hammad Rauf","Engr. Noor Fatima","Engr. Waqas Ahmed"],
    },
    5: {
        "title": "Semester 5 — Integration & Project",
        "monogram": "semester_s5.png",
        "subjects": [
            "Advanced Robotics", "Industrial IoT", "System Integration",
            "Engineering Project", "Professional Practice"
        ],
        "teachers": ["Engr. Salman Farooq","Engr. Areeba Khan","Engr. Hamza Rauf","Engr. Noor Fatima","Engr. Waqas Ahmed"],
    },
}

NAMES = [
    "Ahmed Raza","Bilal Khan","Danish Iqbal","Hamza Noor","Hassan Ali","Huzaifa Ahmed","Imran Shah","Junaid Malik",
    "Kamran Saeed","Muneeb Raza","Noman Tariq","Owais Khan","Rafay Ahmed","Saad Ali","Shahzaib Raza","Talha Khan",
    "Usman Ahmed","Waleed Shah","Zain Malik","Adeel Hussain","Arslan Khan","Fahad Raza","Furqan Ahmed","Haris Iqbal",
    "Ibrahim Khan","Kashif Ali","Mubashir Shah","Naveed Ahmed","Qasim Raza","Rayan Khan","Salman Ahmed","Sameer Ali",
    "Shayan Raza","Shoaib Khan","Taha Ahmed","Umer Farooq","Yasir Shah","Yousuf Ali","Zeeshan Raza","Zohaib Khan"
]

def build_students():
    rng = random.Random(20260923)
    students = []
    idx = 0
    for sem in range(1, 6):
        subjects = SEMESTERS[sem]["subjects"]
        for j in range(8):
            name = NAMES[idx]
            idx += 1
            # Mostly healthy scores, with controlled examples for all 3 statuses.
            scores = {s: rng.randint(62, 94) for s in subjects}
            if sem == 1 and j == 0:
                scores[subjects[0]], scores[subjects[1]], scores[subjects[2]] = 55, 58, 57  # Fail
            elif sem == 2 and j == 1:
                scores[subjects[0]], scores[subjects[1]] = 54, 59  # Re-exam
            elif sem == 3 and j == 2:
                scores[subjects[3]] = 58  # Re-exam
            elif sem == 4 and j == 3:
                scores[subjects[0]], scores[subjects[1]], scores[subjects[2]] = 52, 57, 59  # Fail
            elif sem == 5 and j == 4:
                scores[subjects[0]], scores[subjects[1]] = 56, 59  # Re-exam
            roll = f"PNPI-ME-{sem:02d}-{j+1:02d}"
            students.append({"name": name, "roll": roll, "semester": sem, "scores": scores})
    return students

STUDENTS = build_students()

def status_for(scores):
    below = sum(v < 60 for v in scores.values())
    if below >= 3:
        return "FAIL", below
    if below in (1, 2):
        return "RE-EXAM", below
    return "PASS", 0

def asset(name):
    return str(ASSET_DIR / name)

def show_image(name, caption=None, width=None):
    st.image(asset(name), caption=caption, width=width)

# ------------------------- Sidebar -------------------------
with st.sidebar:
    st.image(asset("pnpi_logo.jpg"), use_container_width=True)
    st.markdown("### PNPI Student Portal")
    st.caption("Pak Navy Polytechnic Institute")
    page = st.radio(
        "Navigate",
        ["Home", "About PNPI", "Study Courses", "Semesters & Students", "Facilities",
         "Student Result Login", "All Final Results", "Classrooms"],
        index=0
    )
    st.divider()
    st.info("📍 West Wharf Road, Karachi\n\n⚙️ Mechatronic Engineering\n\n👤 Principal: Ali Mehdi Jafri")

# ------------------------- Header -------------------------
st.markdown("""
<div class="hero">
  <h1>⚓ Pak Navy Polytechnic Institute (PNPI)</h1>
  <p>Mechatronic Engineering • Student Academic & Campus Portal</p>
  <span class="pill">West Wharf Road, Karachi • 5 Semesters • 40 Students</span>
</div>
""", unsafe_allow_html=True)

# ------------------------- Home -------------------------
if page == "Home":
    c1, c2, c3, c4 = st.columns(4)
    for col, value, label in [
        (c1,"5","Semesters"), (c2,"40","Students"), (c3,"26","Classrooms"), (c4,"1","Technology")
    ]:
        with col:
            st.markdown(f'<div class="metric"><div class="v">{value}</div><div class="l">{label}</div></div>', unsafe_allow_html=True)

    st.markdown('<div class="section-title">Campus Overview</div>', unsafe_allow_html=True)
    left, right = st.columns([1.35, 1])
    with left:
        show_image("campus.jpg", "PNPI campus / institute building")
    with right:
        st.markdown("""
        <div class="card">
          <h3>Mechatronic Engineering</h3>
          <p class="small">A five-semester technology program combining mechanical systems, electronics,
          programming, control, automation and robotics.</p>
          <p><b>Principal:</b> Ali Mehdi Jafri</p>
          <p><b>Location:</b> West Wharf Road, Karachi</p>
          <p><b>Program:</b> Mechatronic Engineering</p>
          <p><b>Assessment rule:</b> 60% is the minimum subject threshold.</p>
        </div>
        """, unsafe_allow_html=True)
        show_image("student_lounge_canteen.jpg", "Student common area / canteen")

    st.markdown('<div class="section-title">Campus Life</div>', unsafe_allow_html=True)
    a,b,c = st.columns(3)
    with a: show_image("classroom.jpg", "Classroom learning")
    with b: show_image("cricket_ground.jpg", "Cricket ground")
    with c: show_image("library.jpg", "Library")

# ------------------------- About -------------------------
elif page == "About PNPI":
    st.markdown('<div class="section-title">About the Institute</div>', unsafe_allow_html=True)
    st.write("Pak Navy Polytechnic Institute (PNPI) is presented here as a professional academic portal for its Mechatronic Engineering program.")
    l,r = st.columns(2)
    with l: show_image("pnpi_logo.jpg", "PNPI monogram / logo")
    with r: show_image("campus.jpg", "Institute building")
    st.markdown("""
    <div class="card">
      <h3>Program Profile</h3>
      <ul>
        <li><b>Technology:</b> Mechatronic Engineering</li>
        <li><b>Duration:</b> 5 semesters</li>
        <li><b>Students:</b> 8 students per semester</li>
        <li><b>Principal:</b> Ali Mehdi Jafri</li>
        <li><b>Location:</b> West Wharf Road, Karachi</li>
        <li><b>Academic facilities:</b> 26 classrooms, mechatronic/electronics labs, library, cricket ground and canteen</li>
      </ul>
    </div>
    """, unsafe_allow_html=True)

# ------------------------- Study Courses -------------------------
elif page == "Study Courses":
    st.markdown('<div class="section-title">Study Courses & Teachers</div>', unsafe_allow_html=True)
    sem = st.selectbox("Select semester", list(SEMESTERS.keys()), format_func=lambda x: f"Semester {x}")
    info = SEMESTERS[sem]
    st.image(asset(info["monogram"]), width=180)
    st.subheader(info["title"])
    df = pd.DataFrame({"Subject": info["subjects"], "Teacher": info["teachers"]})
    st.dataframe(df, use_container_width=True, hide_index=True)

# ------------------------- Semesters -------------------------
elif page == "Semesters & Students":
    st.markdown('<div class="section-title">Five-Semester Student Directory</div>', unsafe_allow_html=True)
    for sem in range(1, 6):
        info = SEMESTERS[sem]
        students = [s for s in STUDENTS if s["semester"] == sem]
        with st.expander(info["title"], expanded=(sem == 1)):
            st.image(asset(info["monogram"]), width=130)
            st.dataframe(
                pd.DataFrame([{"Name": s["name"], "Roll Number": s["roll"]} for s in students]),
                use_container_width=True, hide_index=True
            )

# ------------------------- Facilities -------------------------
elif page == "Facilities":
    st.markdown('<div class="section-title">Campus Facilities</div>', unsafe_allow_html=True)
    facilities = [
        ("26 Classrooms", "classroom.jpg", "26 classrooms for lectures, assessments and practical teaching."),
        ("Mechatronic Lab", "mechatronic_lab.jpg", "Robotics, control and mechatronic project work."),
        ("Trainer & Workshop Area", "trainer_lab.jpg", "Hands-on trainer setups, instruments and project equipment."),
        ("Electronics / Instrumentation Lab", "electronics_lab.jpg", "Bench equipment, test instruments and electronics practice."),
        ("Project Workshop", "project_workshop.jpg", "Team-based prototyping and engineering projects."),
        ("Library", "library.jpg", "Academic reading, reference and study space."),
        ("Cricket Ground", "cricket_ground.jpg", "Outdoor sports and cricket activities."),
        ("Sports Activity", "sports_cricket.jpg", "Sports participation and physical activity."),
        ("Canteen / Student Area", "student_lounge_canteen.jpg", "Student dining and common area."),
    ]
    for i in range(0, len(facilities), 3):
        cols = st.columns(3)
        for col, (title, img, desc) in zip(cols, facilities[i:i+3]):
            with col:
                st.markdown(f'<div class="card"><h3>{title}</h3>', unsafe_allow_html=True)
                show_image(img)
                st.write(desc)
                st.markdown("</div>", unsafe_allow_html=True)

# ------------------------- Result Login -------------------------
elif page == "Student Result Login":
    st.markdown('<div class="section-title">Student Final Result Login</div>', unsafe_allow_html=True)
    st.write("Enter the student's name and roll number to view the final result.")
    c1, c2 = st.columns(2)
    with c1:
        name_input = st.text_input("Student Name")
    with c2:
        roll_input = st.text_input("Roll Number", placeholder="PNPI-ME-01-01")
    if st.button("🔐 View Final Result", type="primary"):
        found = next((s for s in STUDENTS if s["name"].strip().lower() == name_input.strip().lower()
                      and s["roll"].strip().lower() == roll_input.strip().lower()), None)
        if not found:
            st.error("No matching student record found. Check the name and roll number.")
        else:
            status, below = status_for(found["scores"])
            st.success(f"Record found: {found['name']} • {found['roll']}")
            m1,m2,m3 = st.columns(3)
            avg = sum(found["scores"].values()) / len(found["scores"])
            m1.metric("Semester", found["semester"])
            m2.metric("Average", f"{avg:.1f}%")
            m3.metric("Status", status)
            result_df = pd.DataFrame([
                {"Subject": subject, "Marks": marks, "Result": "Pass" if marks >= 60 else "Below 60%"}
                for subject, marks in found["scores"].items()
            ])
            st.dataframe(result_df, use_container_width=True, hide_index=True)
            if status == "FAIL":
                st.error(f"FAIL — {below} subjects are below 60%.")
            elif status == "RE-EXAM":
                st.warning(f"RE-EXAM — {below} subject(s) are below 60%.")
            else:
                st.success("PASS — all subjects are at or above 60%.")

# ------------------------- All Results -------------------------
elif page == "All Final Results":
    st.markdown('<div class="section-title">All Students — Final Results</div>', unsafe_allow_html=True)
    sem_filter = st.selectbox("Semester filter", ["All"] + [f"Semester {i}" for i in range(1,6)])
    rows = []
    selected = STUDENTS if sem_filter == "All" else [s for s in STUDENTS if s["semester"] == int(sem_filter[-1])]
    for s in selected:
        status, below = status_for(s["scores"])
        avg = sum(s["scores"].values()) / len(s["scores"])
        rows.append({"Semester": s["semester"], "Name": s["name"], "Roll Number": s["roll"],
                     "Average %": round(avg,1), "Subjects < 60%": below, "Final Status": status})
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.caption("Result rule: 3 or more subjects below 60% = FAIL; 1–2 subjects below 60% = RE-EXAM; none below 60% = PASS.")

# ------------------------- Classrooms -------------------------
elif page == "Classrooms":
    st.markdown('<div class="section-title">26 Classrooms</div>', unsafe_allow_html=True)
    room_rows = []
    for i in range(1,27):
        room_rows.append({
            "Room": f"PNPI-{100+i}",
            "Type": "Lecture Classroom",
            "Capacity": 30 if i <= 20 else 24,
            "Primary Use": ["Theory","Tutorial","Assessment","Seminar"][i % 4]
        })
    st.dataframe(pd.DataFrame(room_rows), use_container_width=True, hide_index=True)
    st.info("The classroom photo supplied with the project is used as the representative classroom image.")
    show_image("classroom.jpg", "Representative classroom")

st.markdown("---")
st.caption("PNPI • Mechatronic Engineering • Student Academic Portal • Built with Python and Streamlit")
