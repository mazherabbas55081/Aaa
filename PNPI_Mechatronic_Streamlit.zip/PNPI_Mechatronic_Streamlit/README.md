# PNPI Mechatronic Engineering — Streamlit Website

## Included
- `app.py` — complete Python/Streamlit website
- `requirements.txt` — deployment dependencies
- `assets/` — PNPI logo, campus/facility photos and 5 semester monograms

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Student result rule
- 3 or more subjects below 60% → **FAIL**
- 1 or 2 subjects below 60% → **RE-EXAM**
- 0 subjects below 60% → **PASS**

## Demo login
The app contains 40 demo students (8 per semester). Open **Semesters & Students** or **All Final Results** to see their generated names and roll numbers, then use the same name + roll number in **Student Result Login**.

## Notes
The supplied images are used as the website's visual assets. The five semester monograms are generated for this project and are different for each semester.
